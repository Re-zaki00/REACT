import Modal from './components/modal/modal';
import Dashboard from './components/Dashboard/Dashboard';
import {Login} from './components/login/login'
import M from 'materialize-css';
import Users from './components/Users/Users';
import ProductDetail from './components/ProductDetail/ProductDetail'
import Header from './components/header/header'
import './App.css'
import Cart from './components/Cart/Cart';
import {Wishlist} from './components/WishList/WishList';
import React, { useEffect, useRef, useState } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { Home } from './components/home/home'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AddProduct from './components/addProduct/addProduct';
import { Signup } from './components/signup/signup';

function PageNotFound(){
  return <div>
    <h1>Page not found</h1>
  </div>
}

let modalWala;

const App = () => {

  let location = useLocation();

  // let [headerVisibility, setHeaderVisibility] = useState(true);

  // let routes = [
  //   '/', '/category', '/wishlist', 'add-product'
  // ];

  // useEffect(()=>{

  //   if(!routes.includes(location.pathname)){
  //     setHeaderVisibility(false);
  //   }

  // }, [location]);


  let sliderRef = useRef();

  useEffect(()=>{

    M.Carousel.init(sliderRef.current, {});

  }, [])

  return (
      <>
  <div ref={sliderRef} class="carousel">
      <a class="carousel-item" href="#one!"><img src="https://static-01.daraz.pk/p/bdaf2636e51e61b776e9dc0a96672f16.jpg_400x400q75-product.jpg_.webp" /></a>
      <a class="carousel-item" href="#two!"><img src="https://static-01.daraz.pk/p/bdaf2636e51e61b776e9dc0a96672f16.jpg_400x400q75-product.jpg_.webp" /></a>
      <a class="carousel-item" href="#three!"><img src="https://static-01.daraz.pk/p/bdaf2636e51e61b776e9dc0a96672f16.jpg_400x400q75-product.jpg_.webp" /></a>
      <a class="carousel-item" href="#four!"><img src="https://static-01.daraz.pk/p/bdaf2636e51e61b776e9dc0a96672f16.jpg_400x400q75-product.jpg_.webp" /></a>
      <a class="carousel-item" href="#five!"><img src="https://static-01.daraz.pk/p/bdaf2636e51e61b776e9dc0a96672f16.jpg_400x400q75-product.jpg_.webp" /></a>
    </div>

      <Modal></Modal>
      <Header></Header>
      <button onClick={()=>{

      modalWala =M.Modal.init(document.getElementById('modal1'), {});
      modalWala.open();

        setTimeout(() => {
          modalWala.close();
        }, 3000);

      }}>open modal</button>


        {/* {headerVisibility ? <Header></Header> : null} */}

        <Routes>
          
          <Route path='/' element={<Home/>} />
          <Route path='/category/:abc' element={<Home/>} />

          <Route path='/product/:someID' element={<ProductDetail/>} />
          <Route path='/wishlist' element={<Wishlist />} />
          <Route path='/add-product' element={<AddProduct />} />
          <Route path='/cart' element={<Cart />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/login' element={<Login />} />
          <Route path='/users' element={<Users />} />
          <Route path='/dashboard' element={<Dashboard />} />
        
          <Route path='*' element={<PageNotFound />}></Route>
          
          
        </Routes>
        <ToastContainer></ToastContainer>    
      </>
    )
}

export default App