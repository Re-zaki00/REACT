import React from 'react'
import { useDispatch, useSelector } from 'react-redux'

const Users = () => {

    let dispatch = useDispatch();
    let users = useSelector(store=>store.authSection).users

  return (
    <div>

        <table>
            {
                users.map((user, meraIndex)=>{
                    return <tr>
                        <td>{user.email}</td>
                        <td>{user.password}</td>
                        <td>
                            <button onClick={()=>{

                                dispatch({
                                    type:"USER_DELETED",
                                    rowNumber:meraIndex
                                })

                                
                            }}>Delete</button>
                        </td>
                    </tr>
                })
            }
        </table>
    </div>
  )
}

export default Users