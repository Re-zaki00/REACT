import './App.css';
import { Header } from "./components/header/header";
import { Footer } from "./components/footer/footer";


export default ()=>{

    return <div id="app1">
        <Header></Header>
        <main>

        </main>
        <Footer></Footer>
    </div>

};
