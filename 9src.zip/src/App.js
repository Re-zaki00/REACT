import ProductDetail from './components/ProductDetail/ProductDetail'
import Header from './components/header/header'
import './App.css'
import {Wishlist} from './components/WishList/WishList';
import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Home } from './components/home/home'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AddProduct from './components/addProduct/addProduct';
const App = () => {
  return (
    <BrowserRouter>
      
      <Header></Header>

      <Routes>
        
        <Route path='/' element={<Home/>} />
        <Route path='/category/:abc' element={<Home/>} />

        <Route path='/product/:someID' element={<ProductDetail/>} />
        <Route path='/wishlist' element={<Wishlist />} />
        <Route path='/add-product' element={<AddProduct />} />
        
        
      </Routes>
      <ToastContainer></ToastContainer>
    </BrowserRouter>
  
    )
}

export default App