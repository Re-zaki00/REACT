import './App.css';
import { Header } from "./components/header/header";
import { Footer } from "./components/footer/footer";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from './components/home/home';

import Login from './components/login/login';

export default ()=>{

    return <div id="app1">
        <BrowserRouter>
            <Header></Header>
            <main>
                <Routes>
                  <Route path='/' element={<Home />} />
                  <Route path='/login' element={<Login />} />
                  {/* <Route path='/signup' element={<Signup />} /> */}
                </Routes>
            </main>
            <Footer></Footer>
        </BrowserRouter>
    </div>

};
