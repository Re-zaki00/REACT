import React, { useEffect, useState } from 'react'
import './home.css';
import { useSelector } from 'react-redux';
import { Card } from '../card/card';
import { useParams } from 'react-router-dom';
import axios from 'axios';

export const Home = () => {

    let params = useParams();
    let [products, setProducts] = useState([])


    useEffect(()=>{

      loadAds();

      async function loadAds(){

        let resp = await axios.get('/get-ads')
        setProducts(resp.data);
        
      }

    }, [])
    
    // let productsection =  useSelector(store=>{
    //     return store.ProductSection;
    // });

  return (
    <div id='product-section' className='flex'>
            {
                products.map((product)=>{
                   return <Card a1={product}></Card>
                })
            }
        </div>
  )
}


// filter((product)=>{
//   if(params.abc && product.category.toLowerCase()  == params.abc){
//     return true;
//   }else if(!params.abc){
//     return true;  
//   }
  
// }).filter(product=>{
//   if(product.title.toLowerCase().includes(productsection.searched.toLowerCase())){
//     return true;
//   }
// })
