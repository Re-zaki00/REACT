import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom'
import {toast} from 'react-toastify'
const ProductDetail = () => {

    let [ad, setAd] = useState({user:{}})
    let dispatch = useDispatch();

    let params = useParams();

    useEffect(()=>{

      axios.get('/get-ad?id='+params.someID).then((resp)=>{
        setAd(resp.data);
      })

    }, [])
    // params.someID

    // let product= useSelector(store=>store.ProductSection.products)
    // .find(product=>product.id == params.someID);

  return (
    <div>
        <button onClick={()=>{

            dispatch({
                type:"ADD_TO_CART",
                payload:ad
            })

            toast.error("Wow so easy!");

        }}>Add to Cart</button>
        <img src={ad.img} />
        <h1>{ad.title}</h1>
        <h1>{ad.price}</h1>
        <h1>{ad.priceWithCurrency}</h1>
        <h1>{ad.user.email}</h1>
    </div>
  )
}

export default ProductDetail