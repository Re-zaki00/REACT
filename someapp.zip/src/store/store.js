import { createStore, combineReducers } from "redux";
import { v4 } from "uuid";

// npm install react-toastify;

// npm install uuid

let puranData = {
    searched:'',
    orders:[],
    products:[
        
    ]
}

function ProductSection(oldData=puranData, newData){

    oldData = {
        ...oldData,

    };

    switch(newData.type){

        case 'SEARCHED_PRODUCT':
            oldData.searched = newData.payload;
            break;

        case 'ADD_PRODUCT':
            oldData.products.push(newData.payload);
            break;

        case 'ADD_TO_CART':
            oldData.orders.push(newData.payload);
        break;
        
        case 'TOGGLE_LIKE':
            let item  = oldData.products.find(product=>product.id == newData.payload);
            item.liked = !item.liked
            console.log(item)
            break;

    }

    return oldData;

}

let puranAuthData = {
loggedWalaUser:null,
    users:[]
}

function authSection(oldData=puranAuthData, newData){

    oldData = {
        ...oldData        
    };

    if(newData.type == "USER_ADDED"){
        oldData.users.push(newData.payload);
    }else if(newData.type == "USER_DELETED"){        
        oldData.users.splice(oldData.rowNumber, 1);
        oldData.rowNumber = -1;
    }else if(newData.type == "ROW_SELECTED"){
        oldData.rowNumber = newData.payload;
    }else if(newData.type == "USER_LOGGED"){
        oldData.loggedWalaUser = newData.payload;
    }else if(newData.type == "USER_LOGGED_OUT"){
        oldData.loggedWalaUser = null;
    }

    
    
    

    return oldData;
}

let allSections = combineReducers({ProductSection, authSection})

export let store = createStore(allSections);