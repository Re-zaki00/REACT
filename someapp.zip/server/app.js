let express = require('express');
let mongoose = require('mongoose');

let User =  require('./db/models/user');

mongoose.connect('mongodb://localhost:27017/meriSomeDB').then((conn)=>{
    console.log(conn)
}).catch((err)=>{
    console.log(err);
});

// npm install mongoose

let app = express();

app.use(express.json());

app.delete('/user-delete', async(req, res)=>{
    let users = await User.findByIdAndDelete(req.query.abc);
    res.json(users);
});

app.get('/user-lao', async(req, res)=>{
    let users = await User.find();
    res.json(users);
});

app.post('/signup', async(req, res)=>{

    let newUser =  new User();
    newUser.email =  req.body.email;    
    newUser.password =  req.body.password;    

    await newUser.save();

    res.json({})

})






app.listen(4030, ()=>{
    console.log('server chal paring')
});