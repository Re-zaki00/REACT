let mongoose = require('mongoose');

let userSchema = mongoose.Schema({
    email:String,
    archive:false,
    password:String,
    city:String,
    ads:[]    
});

module.exports = mongoose.model('user', userSchema)


