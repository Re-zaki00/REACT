import { useEffect } from "react"
import M from 'materialize-css';

export default ()=>{

  useEffect(()=>{

    M.Carousel.init(document.getElementById('meraC'), {});


  }, [])

    return  <div id="meraC" className="carousel">
    <a className="carousel-item" href="#one!">
      <img src="https://icms-image.slatic.net/images/ims-web/2c65c7eb-b3f0-4593-8277-0bf4f4907827.jpg_1200x1200.jpg" />
    </a>
    <a className="carousel-item" href="#two!">
      <img src="https://icms-image.slatic.net/images/ims-web/5022e945-230b-4a29-96e1-4e4e55d9dbac.jpg" />
    </a>
    <a className="carousel-item" href="#three!">
      <img src="https://icms-image.slatic.net/images/ims-web/1bdaed75-a426-4b0f-9b15-e92f6a44a64e.jpg" />
    </a>
    <a className="carousel-item" href="#four!">
      <img src="https://icms-image.slatic.net/images/ims-web/f5caa31c-7f4f-492a-9d38-142f7f08b347.jpg" />
    </a>
    {/* <a className="carousel-item" href="#five!">
      <img src="https://lorempixel.com/250/250/nature/5" />
    </a> */}
  </div>
  


}