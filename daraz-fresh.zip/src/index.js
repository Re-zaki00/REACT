import  App  from "./App";

import  ReactDOM from "react-dom";


ReactDOM.render(<div>
    <App></App>
    </div>, document.getElementById('root') );

// ReactDOM.render(<h1>yeh 2nd wala</h1>, document.getElementById('root2') );








