import React from 'react';
import './card.css';

export const Card = ({a1}) => {
  return (
    <div className="card">
  <div className="card-image">
    <img src={a1.img} />
    <span className="card-title">{a1.title}</span>
  </div>
  <div className="card-content">
    <span className={'like-btn'}>
      <svg aria-label="Favorite icon" class="_08813525"><use xlink:href="/assets/iconFavoriteUnselected_noinline.e938669ff34db8fd19c07ac3b2b65fcc.svg#icon"></use></svg>
    </span>
    <p>
      I am a very simple card. I am good at containing small bits of
      information. I am convenient because I require little markup to use
      effectively.
    </p>
  </div>
  <div className="card-action">
    <a href="#">{a1.price}</a>
  </div>
</div>

  )
}
