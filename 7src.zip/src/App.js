


import './App.css';
import React from 'react'
import { Provider, useDispatch, useSelector } from 'react-redux'
import { store } from './store/store'

function Child({a1}){

  let dispatch = useDispatch();
  
  const addData = ()=>{

    let name = prompt("enter name");
    
    dispatch({
      type:"USER_ADDED",
      payload: name
    })

  }

  return <div>
    <button onClick={addData}>Add Name</button>
    <button onClick={()=>{

      dispatch({
        type:"USER_DELETED",
        // payload: name
      })

    }}>Delte</button>
  </div>
}

function Users(){

  let dispatch = useDispatch();
  let section = useSelector(store=>store.authSection);

  let rNum = section.rowNumber;

  return <table>
    {
      section.users.map((user, mINdez)=>{
        return <tr className={rNum == mINdez ? 'selected' : ''} onClick={()=>{

          dispatch({
            type:"ROW_SELECTED",
            payload:mINdez
          })

        }}>
          <td>{user}</td>
          {/* <td>
            <button onClick={()=>{

              dispatch({
                type:"USER_DELTED",
                payload:mINdez
              });

            }}>Delete</button>
          </td> */}
        </tr>
      })
    }
  </table>
}

// Redux
// Site ka data center

const App = () => {

  let name = 'ali'

  return (
    <div>
      <Provider store={store}>

        <Child></Child>

        <Users></Users>

      </Provider>

    </div>
  )
}

export default App