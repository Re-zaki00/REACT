import { createStore, combineReducers } from "redux";

let puranData = {
    products:[]
}

function ProductSection(oldData=puranData, newData){

    return oldData;

}

let puranAuthData = {
    users:[]
}

function authSection(oldData=puranAuthData, newData){

    oldData = {
        ...oldData        
    };

    if(newData.type == "USER_ADDED"){
        oldData.users.push(newData.payload);
    }else if(newData.type == "USER_DELETED"){        
        oldData.users.splice(oldData.rowNumber, 1);
        oldData.rowNumber = -1;
    }else if(newData.type == "ROW_SELECTED"){
        oldData.rowNumber = newData.payload;
    }

    
    

    return oldData;
}

let allSections = combineReducers({ProductSection, authSection})

export let store = createStore(allSections);