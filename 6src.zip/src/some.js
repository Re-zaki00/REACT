
export let name = 'FSD';

export default {
     name:'ali'
}

export  function say(){
    alert('say is chaling');
}

export function hello(){
    alert('code chaling');
}