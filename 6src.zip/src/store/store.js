import { createStore, combineReducers } from "redux";

function studentSection(){
    return  ['ali', 'yahya', 'aqsa', 'rameez'];
}

function teacherSection(){
    return ['ahmed', 'farhan', 'dawood'];
}

let baraSection = combineReducers({studentSection, teacherSection});

let myStore = createStore(baraSection);

export default myStore;