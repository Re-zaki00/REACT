import { Provider, useSelector } from "react-redux";
import myStore from "./store/store";

function Child({name}){
    return <div>
        <h1>{name}</h1>
    </div>
}

function User({data}){
    return <tr>
        <td>{data}</td>
    </tr>
}


export default ()=>{


    // redux-core
    // redux-toolkit

    // redux-store
    // react-redux

    // npm install redux react-redux

    // let users = ['ali', 'yahya', 'aqsa'];

    let students = useSelector((store)=>{
        return store.studentSection
    });

    let teachers = useSelector((store)=>{
        return store.teacherSection
    });

    return <div>
        <h1>{students[1]   }</h1>
            {/* <table>
                {
                    students.map((name)=>{
                        return <User data={name}></User>
                    })
                }
                  {
                    teachers.map((name)=>{
                        return <User data={name}></User>
                    })
                }
            </table> */}
        {/* </Provider> */}
        {/* <Child name='ali'></Child> */}
    </div>
    
}