export function Card({name, a1}){
    return <div className='card'>
        <div>{name}</div>
        <div>{a1}</div>
    </div>
}