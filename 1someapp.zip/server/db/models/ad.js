let mongoose = require('mongoose');

let adSchema = mongoose.Schema({
    price:Number,
    title:String,
    img:String
});

module.exports = mongoose.model('ad', adSchema)