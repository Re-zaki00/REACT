import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';

const Users = () => {

    let [users, setUsers] = useState([])
    
    useEffect(()=>{

        axios.get('/user-lao').then((resp)=>{
            console.log(resp.data);
            setUsers(resp.data);
        });

    }, []);
    

    // let users = useSelector(store=>store.authSection).users

  return (
    <div>

        <table>
            {
                users.map((user, meraIndex)=>{
                    return <tr>
                        <td>{user.email}</td>
                        <td>{user.password}</td>
                        <td>
                            <button onClick={()=>{

                                axios.delete('/user-delete?abc='+user._id).then(()=>{
                                    
                                    users.splice(meraIndex, 1);
                                    setUsers([...users]);

                                })

                            }}>Delete</button>

                                <button onClick={()=>{

                                    user.email =  prompt('enter email');
                                    user.password =  prompt('enter pasword');

                                    axios.put('/user-update', user).then(()=>{

                                    setUsers([...users])    ;

                                    });
                        
                                // dispatch({
                                //     type:"USER_DELETED",
                                //     rowNumber:meraIndex
                                // })


                                }}>Update</button>
                        </td>
                    </tr>
                })
            }
        </table>
    </div>
  )
}

export default Users