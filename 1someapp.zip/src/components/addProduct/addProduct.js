

import axios from 'axios';
import React from 'react'
import { useForm } from 'react-hook-form'
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';


const AddProduct = () => {
    
    let {register, handleSubmit} =  useForm();
    let dispatch = useDispatch();
    let user = useSelector(store=>store.authSection.loggedWalaUser)
    
    const saveProduct = (data)=>{

      axios.post('/create-ad', data).then(()=>{
        toast.success("Ad create hogya wa");
      })

    }

  return (
    <div>
        <form onSubmit={handleSubmit(saveProduct)}>

            
            <input {...register('title')} type="text" placeholder='title' /> <br/>
            <input {...register('price')} type="number" placeholder='price' /><br/>
            {/* <input {...register('file')} type="file" placeholder='FIle' /><br/> */}
            <button>Create Product</button>
        </form>
    </div>
  )
}

export default AddProduct