import Slider from "./slider/slider"

export default ()=>{

    let categories = [
        {
            
        }
    ]

return <div>

    <Slider />
    
    {/* Category UI with a react plugin */}


</div>

}